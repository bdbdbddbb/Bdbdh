import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { AccountsList } from './components/AccountsList';
import { DeveloperLogin } from './components/DeveloperLogin';
import { DeveloperPanel } from './components/DeveloperPanel';
import { PurchaseForm } from './components/PurchaseForm';
import { useAccounts } from './hooks/useAccounts';
import { usePurchases } from './hooks/usePurchases';
import { useAuth } from './contexts/AuthContext';
import type { Account } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState<'accounts' | 'developer'>('accounts');
  const [isDeveloperAuthenticated, setIsDeveloperAuthenticated] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  
  const { session, loading: authLoading } = useAuth();
  const { accounts, loading: accountsLoading, addAccount } = useAccounts();
  const { purchases, loading: purchasesLoading, addPurchase } = usePurchases();

  const handlePurchase = (account: Account) => {
    setSelectedAccount(account);
  };

  const handlePurchaseSubmit = async (whatsappNumber: string, rechargeCode: string) => {
    if (selectedAccount) {
      const purchase = await addPurchase({
        accountId: selectedAccount.id,
        whatsappNumber,
        rechargeCode,
      });

      if (purchase) {
        setSelectedAccount(null);
        window.open(`https://wa.me/${whatsappNumber}`, '_blank');
      }
    }
  };

  if (authLoading || accountsLoading || purchasesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar onPageChange={setCurrentPage} />
      <Header />
      
      <main className="mr-16 mt-16">
        {currentPage === 'accounts' && !selectedAccount && (
          <AccountsList accounts={accounts} onPurchase={handlePurchase} />
        )}
        
        {currentPage === 'accounts' && selectedAccount && (
          <PurchaseForm
            account={selectedAccount}
            onSubmit={handlePurchaseSubmit}
          />
        )}
        
        {currentPage === 'developer' && !isDeveloperAuthenticated && (
          <DeveloperLogin onLogin={() => setIsDeveloperAuthenticated(true)} />
        )}
        
        {currentPage === 'developer' && isDeveloperAuthenticated && session && (
          <DeveloperPanel
            accounts={accounts}
            purchases={purchases}
            onAddAccount={addAccount}
          />
        )}
      </main>
    </div>
  );
}

export default App;
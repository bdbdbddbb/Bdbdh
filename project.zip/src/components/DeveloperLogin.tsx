import React, { useState } from 'react';
import { Lock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface DeveloperLoginProps {
  onLogin: () => void;
}

export function DeveloperLogin({ onLogin }: DeveloperLoginProps) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const { signIn } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (code === '4109') {
      try {
        await signIn('developer@example.com', 'developer-password');
        onLogin();
      } catch (err) {
        setError('فشل تسجيل الدخول');
      }
    } else {
      setError('رمز غير صحيح');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <div className="flex justify-center mb-6">
          <Lock size={48} className="text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-center mb-6">لوحة المطور</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="password"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="أدخل رمز الدخول"
            className="w-full px-4 py-2 border rounded-lg mb-4 text-right"
          />
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
          >
            دخول
          </button>
        </form>
      </div>
    </div>
  );
}
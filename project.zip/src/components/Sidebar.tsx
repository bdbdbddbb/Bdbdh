import React from 'react';
import { Menu, Store, User } from 'lucide-react';

interface SidebarProps {
  onPageChange: (page: 'accounts' | 'developer') => void;
}

export function Sidebar({ onPageChange }: SidebarProps) {
  return (
    <div className="fixed right-0 top-0 h-full w-16 bg-gray-900 flex flex-col items-center py-4 space-y-6">
      <button className="text-white p-3 hover:bg-gray-800 rounded-lg">
        <Menu size={24} />
      </button>
      <button 
        onClick={() => onPageChange('accounts')}
        className="text-white p-3 hover:bg-gray-800 rounded-lg"
        title="الحسابات"
      >
        <Store size={24} />
      </button>
      <button 
        onClick={() => onPageChange('developer')}
        className="text-white p-3 hover:bg-gray-800 rounded-lg"
        title="لوحة المطور"
      >
        <User size={24} />
      </button>
    </div>
  );
}
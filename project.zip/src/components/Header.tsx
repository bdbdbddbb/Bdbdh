import React from 'react';
import { Home } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white shadow-sm fixed top-0 right-16 left-0 z-10">
      <div className="px-6 py-4 flex items-center">
        <Home className="text-blue-600 ml-2" size={24} />
        <h1 className="text-xl font-bold">الرئيسية</h1>
      </div>
    </header>
  );
}
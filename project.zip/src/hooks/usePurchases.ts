import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Purchase } from '../types';

export function usePurchases() {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchPurchases();
  }, []);

  async function fetchPurchases() {
    try {
      const { data, error } = await supabase
        .from('purchases')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPurchases(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  }

  async function addPurchase(purchase: Omit<Purchase, 'id' | 'timestamp'>) {
    try {
      const { data, error } = await supabase
        .from('purchases')
        .insert([{
          ...purchase,
          status: 'pending'
        }])
        .select()
        .single();

      if (error) throw error;
      setPurchases(prev => [data, ...prev]);
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      return null;
    }
  }

  return { purchases, loading, error, addPurchase };
}